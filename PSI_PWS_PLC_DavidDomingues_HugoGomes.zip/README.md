
Programação para a Web - Servidor<br><br>
HD Services - Projeto de lançamento de folhas de obra<br><br>

![Logo](imagem.png)<br><br><br>


David Domingues, 2220897<br><br>
Hugo Gomes, 2220893<br><br>
Ruben Soares, 2220900<br><br><br>


| Username   |  Password | role |
|------------|:---------:|:----:|
| adminn     |  passw0rd |   1  |
| renatosilva|  passw0rd |   2  |
| isagonca   |  passw0rd |   2  |
| resteves   |  passw0rd |   3  |
| pedrodias  |  passw0rd |   3  |
| jduarte    |  passw0rd |   3  |

<br><br>
1 - Administrador<br>
2 - Funcionário<br>
3 - Cliente
