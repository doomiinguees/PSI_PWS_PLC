<?php
    require_once 'framework/Router.php';
    $router = new Router();
    $router -> route();
?>