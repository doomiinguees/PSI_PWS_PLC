<?php

class User extends \ActiveRecord\Model
{
    static $validates_presence_of = array(
        //validacao de dados
    );
}